import { motion } from "framer-motion";
import { RiRobotFill, RiMagicLine, RiShieldCheckFill, RiPlayFill } from "react-icons/ri";
import FeatureCard from "@/components/FeatureCard";

export default function About() {
  const features = [
    {
      icon: <RiRobotFill className="text-2xl text-[#1E90FF]" />,
      title: "Advanced AI Technology",
      description: "Powered by ChatGPT API, our platform brings you the latest in AI language model capabilities for natural, helpful conversations.",
      colorClass: "from-[#1E90FF]/10 to-[#1E90FF]/10",
      hoverBorderClass: "hover:border-[#1E90FF]",
      hoverTextClass: "group-hover:text-[#1E90FF]"
    },
    {
      icon: <RiMagicLine className="text-2xl text-[#FF1493]" />,
      title: "Intuitive Experience",
      description: "Our user-friendly interface makes accessing AI capabilities simple and enjoyable with immediate, helpful responses.",
      colorClass: "from-[#FF1493]/10 to-[#FF1493]/10",
      hoverBorderClass: "hover:border-[#FF1493]",
      hoverTextClass: "group-hover:text-[#FF1493]"
    },
    {
      icon: <RiShieldCheckFill className="text-2xl text-[#FFD700]" />,
      title: "Secure and Private",
      description: "Your conversations remain private and secure, with transparent data handling practices and advanced security measures.",
      colorClass: "from-[#FFD700]/10 to-[#FFD700]/10",
      hoverBorderClass: "hover:border-[#FFD700]",
      hoverTextClass: "group-hover:text-[#FFD700]"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 section-title-underline">
            About Our <span className="text-[#1E90FF]">AI Chat</span> Platform
          </h2>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            Discover how our cutting-edge AI integration can transform your experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <FeatureCard
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                colorClass={feature.colorClass}
                hoverBorderClass={feature.hoverBorderClass}
                hoverTextClass={feature.hoverTextClass}
              />
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="mt-20 bg-gradient-to-r from-[#1E90FF]/5 to-[#FF1493]/5 dark:from-[#1E90FF]/10 dark:to-[#FF1493]/10 rounded-2xl p-8 lg:p-12"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div>
              <h3 className="text-2xl sm:text-3xl font-bold mb-4">How Our AI Chat Works</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 rounded-full bg-[#1E90FF] text-white flex items-center justify-center flex-shrink-0">1</div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Ask a Question</h4>
                    <p className="text-gray-700 dark:text-gray-300">Type your query in natural language just as you would ask a human.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 rounded-full bg-[#FF1493] text-white flex items-center justify-center flex-shrink-0">2</div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">AI Processing</h4>
                    <p className="text-gray-700 dark:text-gray-300">Our API connects to ChatGPT, which analyzes your query and generates a relevant response.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 rounded-full bg-[#FFD700] text-white flex items-center justify-center flex-shrink-0">3</div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Instant Response</h4>
                    <p className="text-gray-700 dark:text-gray-300">Receive a thoughtful, contextual response in seconds, ready for follow-up questions.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-video bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-[#1E90FF] flex items-center justify-center cursor-pointer hover:bg-blue-600 transition-colors duration-300 z-10">
                    <RiPlayFill className="text-4xl text-white" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-900/50 to-gray-900/30"></div>
                  <div className="absolute inset-0 bg-gray-900/20"></div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
