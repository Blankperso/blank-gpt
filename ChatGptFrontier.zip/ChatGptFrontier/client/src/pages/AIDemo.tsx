import { motion } from "framer-motion";
import ChatInterface from "@/components/ChatInterface";
import { RiQuestionAnswerLine, RiCodeBoxLine, RiLightbulbLine } from "react-icons/ri";

export default function AIDemo() {
  return (
    <section id="demo" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 section-title-underline">
            Try Our <span className="text-[#1E90FF]">AI Chat</span> Demo
          </h2>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            Experience the power of ChatGPT API with our interactive demo. Ask any question to see how it works!
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <ChatInterface />
        </motion.div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.4 }}
          >
            <div className="text-[#1E90FF] text-4xl mb-2">
              <RiQuestionAnswerLine className="mx-auto" />
            </div>
            <h3 className="font-bold text-lg mb-2">Ask Anything</h3>
            <p className="text-gray-700 dark:text-gray-300">Try asking about facts, creative ideas, or programming help.</p>
          </motion.div>
          
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.5 }}
          >
            <div className="text-[#FF1493] text-4xl mb-2">
              <RiCodeBoxLine className="mx-auto" />
            </div>
            <h3 className="font-bold text-lg mb-2">Get Code Examples</h3>
            <p className="text-gray-700 dark:text-gray-300">Request snippets in various programming languages with explanations.</p>
          </motion.div>
          
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.6 }}
          >
            <div className="text-[#FFD700] text-4xl mb-2">
              <RiLightbulbLine className="mx-auto" />
            </div>
            <h3 className="font-bold text-lg mb-2">Brainstorm Ideas</h3>
            <p className="text-gray-700 dark:text-gray-300">Generate creative solutions and explore possibilities together.</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
