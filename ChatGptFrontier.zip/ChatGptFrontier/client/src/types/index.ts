export interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface Contact {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}
