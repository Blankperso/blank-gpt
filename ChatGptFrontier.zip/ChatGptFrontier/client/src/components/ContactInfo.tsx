import { RiMailLine, RiPhoneLine, RiMapPinLine, RiTwitterFill, RiLinkedinFill, RiGithubFill, RiInstagramFill } from "react-icons/ri";

export default function ContactInfo() {
  return (
    <div>
      <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700 mb-8">
        <h3 className="text-2xl font-bold font-inter mb-6">Contact Information</h3>
        
        <div className="space-y-6">
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 rounded-full bg-[#1E90FF]/10 flex items-center justify-center text-[#1E90FF]">
              <RiMailLine className="text-xl" />
            </div>
            <div>
              <h4 className="font-medium text-gray-700 dark:text-gray-300">Email</h4>
              <a href="mailto:contact@aichatgpt.com" className="text-[#1E90FF] hover:underline">contact@aichatgpt.com</a>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 rounded-full bg-[#FF1493]/10 flex items-center justify-center text-[#FF1493]">
              <RiPhoneLine className="text-xl" />
            </div>
            <div>
              <h4 className="font-medium text-gray-700 dark:text-gray-300">Phone</h4>
              <a href="tel:+1234567890" className="text-[#FF1493] hover:underline">+1 (234) 567-890</a>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 rounded-full bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700]">
              <RiMapPinLine className="text-xl" />
            </div>
            <div>
              <h4 className="font-medium text-gray-700 dark:text-gray-300">Location</h4>
              <p className="text-gray-600 dark:text-gray-400">AI Innovation Center<br />123 Tech Street<br />San Francisco, CA 94105</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-bold font-inter mb-4">Follow Us</h3>
        <div className="flex space-x-4">
          <a href="#" className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#1E90FF] hover:text-white transition-colors duration-300">
            <RiTwitterFill className="text-xl" />
          </a>
          <a href="#" className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#1E90FF] hover:text-white transition-colors duration-300">
            <RiLinkedinFill className="text-xl" />
          </a>
          <a href="#" className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#1E90FF] hover:text-white transition-colors duration-300">
            <RiGithubFill className="text-xl" />
          </a>
          <a href="#" className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-[#1E90FF] hover:text-white transition-colors duration-300">
            <RiInstagramFill className="text-xl" />
          </a>
        </div>
      </div>
    </div>
  );
}
