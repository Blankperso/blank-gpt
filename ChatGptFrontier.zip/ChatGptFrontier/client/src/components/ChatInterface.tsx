import { useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RiDeleteBinLine, RiSettings3Line, RiSendPlaneFill } from "react-icons/ri";
import useChat from "@/hooks/useChat";

export default function ChatInterface() {
  const { 
    messages, 
    inputValue, 
    setInputValue, 
    sendMessage, 
    clearChat, 
    isLoading 
  } = useChat();
  
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const chatContainerRef = useRef<HTMLDivElement | null>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isLoading) {
      sendMessage();
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="p-4 bg-gradient-to-r from-[#1E90FF] to-[#FF1493] text-white">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg">Blanks AI Assistant</h3>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:bg-white/20 rounded-full text-white" 
              onClick={clearChat}
              title="Clear chat"
            >
              <RiDeleteBinLine />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:bg-white/20 rounded-full text-white" 
              title="Settings"
            >
              <RiSettings3Line />
            </Button>
          </div>
        </div>
      </div>
      
      <div 
        ref={chatContainerRef}
        className="chat-container p-4 overflow-y-auto space-y-4 bg-gray-50 dark:bg-gray-900"
      >
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`chat-message flex ${msg.role === 'user' ? 'justify-end' : ''}`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#1E90FF] to-[#FF1493] flex-shrink-0 flex items-center justify-center text-white font-bold mr-3">
                B
              </div>
            )}
            <div className={`${
              msg.role === 'user' 
                ? 'bg-[#1E90FF] text-white' 
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
              } rounded-lg p-3 shadow-md max-w-md`}>
              <p className={msg.role === 'user' ? 'text-white' : 'text-gray-700 dark:text-gray-300'}>
                {msg.content}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="chat-message flex">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#1E90FF] to-[#FF1493] flex-shrink-0 flex items-center justify-center text-white font-bold mr-3">
              B
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow max-w-md">
              <div className="flex space-x-2">
                <div className="h-2 w-2 bg-[#1E90FF] rounded-full animate-pulse"></div>
                <div className="h-2 w-2 bg-[#1E90FF] rounded-full animate-pulse delay-100"></div>
                <div className="h-2 w-2 bg-[#1E90FF] rounded-full animate-pulse delay-200"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <Input 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message here..." 
            className="flex-1 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 rounded-lg py-3 px-4 focus:ring-2 focus:ring-[#1E90FF] dark:focus:ring-[#1E90FF] focus:border-transparent text-gray-700 dark:text-gray-300"
          />
          <Button 
            type="submit" 
            variant="gradient"
            disabled={!inputValue.trim() || isLoading}
            className="px-4 py-3 flex items-center"
          >
            <span className="mr-2">Send</span>
            <RiSendPlaneFill />
          </Button>
        </form>
        <div className="text-center mt-3 text-sm text-gray-500 dark:text-gray-400">
          <p>Powered by Blanks AI • Responses may take a moment to generate</p>
        </div>
      </div>
    </div>
  );
}
