import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 bg-gradient-to-br from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <motion.div 
            className="space-y-6 max-w-xl"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-inter leading-tight">
              Experience the Power of <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#1E90FF] via-[#FF1493] to-[#FFD700]">Blanks AI</span>
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300">
              Connect with advanced AI technology through our intuitive chat interface powered by state-of-the-art language models.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
              <Link href="/demo">
                <Button variant="electric-blue" size="xl">
                  Try AI Chat Now
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="outline" size="xl" className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 hover:border-[#1E90FF] dark:hover:border-[#1E90FF] hover:shadow-lg">
                  Learn More
                </Button>
              </Link>
            </div>
          </motion.div>

          <motion.div 
            className="relative hidden md:block"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          >
            <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#FFD700]/30 rounded-full filter blur-3xl animate-pulse-slow"></div>
            <div className="absolute -bottom-10 -right-10 w-60 h-60 bg-[#FF1493]/20 rounded-full filter blur-3xl animate-pulse-slow"></div>
            <div className="relative bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 hover-float">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <div className="flex-1 text-center text-sm text-gray-500 dark:text-gray-400">AI Chat Interface</div>
              </div>
              <div className="space-y-4">
                <div className="flex justify-end">
                  <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-md">
                    <p className="text-gray-700 dark:text-gray-300">Hello AI, can you help me with some creative ideas?</p>
                  </div>
                </div>
                <div className="flex">
                  <div className="bg-[#1E90FF]/10 border border-[#1E90FF]/30 rounded-lg p-3 max-w-md">
                    <p className="text-gray-700 dark:text-gray-300">Of course! I'd be happy to help with creative ideas. What kind of project are you working on?</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-md">
                    <p className="text-gray-700 dark:text-gray-300">I'm designing a website and need some inspiration.</p>
                  </div>
                </div>
                <div className="flex">
                  <div className="bg-[#1E90FF]/10 border border-[#1E90FF]/30 rounded-lg p-3 max-w-md">
                    <p className="text-gray-700 dark:text-gray-300">Great! For website design, you might consider these trends: neumorphism, glassmorphism, bold typography, or interactive 3D elements...</p>
                  </div>
                </div>
              </div>
              <div className="mt-4 flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg p-2">
                <input 
                  type="text" 
                  placeholder="Type your message..." 
                  className="flex-1 bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white" 
                  disabled 
                />
                <button className="text-[#1E90FF] hover:text-blue-700 transition-colors p-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-send">
                    <path d="m22 2-7 20-4-9-9-4Z" />
                    <path d="M22 2 11 13" />
                  </svg>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
