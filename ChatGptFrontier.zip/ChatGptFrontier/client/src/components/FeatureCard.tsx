import { ReactNode } from "react";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  colorClass: string;
  hoverBorderClass: string;
  hoverTextClass: string;
}

export default function FeatureCard({
  icon,
  title,
  description,
  colorClass,
  hoverBorderClass,
  hoverTextClass
}: FeatureCardProps) {
  return (
    <div className={`bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 ${hoverBorderClass} transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group`}>
      <div className={`w-14 h-14 rounded-full bg-gradient-to-r ${colorClass} flex items-center justify-center mb-4 group-hover:bg-opacity-20 transition-colors duration-300`}>
        {icon}
      </div>
      <h3 className={`text-xl font-bold font-inter mb-3 ${hoverTextClass} transition-colors duration-300`}>{title}</h3>
      <p className="text-gray-700 dark:text-gray-300">
        {description}
      </p>
    </div>
  );
}
