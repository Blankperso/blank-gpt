import { Link } from "wouter";
import { 
  RiTwitterFill, 
  RiLinkedinFill, 
  RiGithubFill, 
  RiInstagramFill 
} from "react-icons/ri";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#1E90FF] via-[#FF1493] to-[#FFD700] flex items-center justify-center text-white font-bold text-xl">
                AI
              </div>
              <span className="text-xl font-bold font-inter">AIChat<span className="text-[#1E90FF]">GPT</span></span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Experience the future of conversational AI with our interactive ChatGPT API integration.
              Powerful, user-friendly, and designed for seamless interaction.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">
                <RiTwitterFill className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">
                <RiLinkedinFill className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">
                <RiGithubFill className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">
                <RiInstagramFill className="text-xl" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/"><div className="text-gray-400 hover:text-white transition-colors duration-300">Home</div></Link></li>
              <li><Link href="/about"><div className="text-gray-400 hover:text-white transition-colors duration-300">About</div></Link></li>
              <li><Link href="/demo"><div className="text-gray-400 hover:text-white transition-colors duration-300">AI Demo</div></Link></li>
              <li><Link href="/contact"><div className="text-gray-400 hover:text-white transition-colors duration-300">Contact</div></Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">API Documentation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Developers</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Pricing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Blog</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            &copy; {currentYear} Blanks<span className="text-[#1E90FF]">AI</span>. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-500 hover:text-white text-sm transition-colors duration-300">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-white text-sm transition-colors duration-300">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-white text-sm transition-colors duration-300">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
