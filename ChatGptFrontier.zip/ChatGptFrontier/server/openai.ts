import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "your-api-key-here"
});

// Demo responses for when the API isn't available
const demoResponses: Record<string, string> = {
  "hi": "Hello there! How can I assist you today?",
  "hello": "Hi! I'm your AI assistant. How can I help you?",
  "how are you": "I'm functioning well, thank you for asking! How can I help you today?",
  "what can you do": "I can help with a wide range of tasks including answering questions, providing information, brainstorming ideas, explaining concepts, writing content, and more. What would you like assistance with?",
  "who are you": "I'm an AI assistant designed to provide helpful, accurate, and friendly responses. I'm here to assist you with information and answer your questions!",
  "weather": "I don't have real-time data access to check current weather conditions. For accurate weather information, you might want to check a weather service or app.",
  "thanks": "You're welcome! Feel free to ask if you need any further assistance.",
  "thank you": "You're welcome! I'm happy I could help. Let me know if you need anything else.",
  "help": "I'm here to help! You can ask me questions, request information, or seek assistance on various topics. What can I help you with today?",
};

export async function chatWithGPT(message: string): Promise<string> {
  try {
    // Look for a matching demo response
    const lowerMessage = message.toLowerCase().trim();
    
    // Check for exact matches first
    if (demoResponses[lowerMessage]) {
      return demoResponses[lowerMessage];
    }
    
    // Check for partial matches
    for (const [key, response] of Object.entries(demoResponses)) {
      if (lowerMessage.includes(key)) {
        return response;
      }
    }
    
    // Make a request to the OpenAI API
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // Using the latest model
        messages: [
          {
            role: "system",
            content: "You are a helpful AI assistant that provides informative, concise, and friendly responses. You can help with a wide range of topics including creative ideas, code examples, explanations of complex topics, brainstorming, and more."
          },
          {
            role: "user",
            content: message
          }
        ],
        temperature: 0.7, // Controls randomness: lower is more deterministic
        max_tokens: 1000, // Limit token usage for efficiency
      });

      // Extract and return the generated text
      return response.choices[0].message.content || "I couldn't generate a response at this time.";
    } catch (apiError) {
      console.error("Error calling OpenAI API:", apiError);
      
      // For messages with no matching demo response, provide a fallback
      return "I understand you're asking about something specific, but I'm currently in demo mode due to API limitations. I can still help with basic questions and information. Feel free to try a different question!";
    }
  } catch (error) {
    console.error("Unexpected error in chatWithGPT:", error);
    return "Sorry, I encountered an unexpected error while processing your request. Please try again later.";
  }
}
