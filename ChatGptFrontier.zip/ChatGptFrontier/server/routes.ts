import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { chatWithGPT } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      // Validate request
      const schema = z.object({
        message: z.string().min(1, "Message is required")
      });
      
      const validation = schema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid request", 
          errors: validation.error.format() 
        });
      }
      
      const { message } = validation.data;
      
      // Call OpenAI API
      const response = await chatWithGPT(message);
      
      res.json({ message: response });
    } catch (error) {
      console.error("Error in chat endpoint:", error);
      res.status(500).json({ 
        message: "An error occurred while processing your request" 
      });
    }
  });

  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate request
      const schema = z.object({
        name: z.string().min(2, "Name must be at least 2 characters"),
        email: z.string().email("Invalid email address"),
        subject: z.string().min(2, "Subject must be at least 2 characters"),
        message: z.string().min(10, "Message must be at least 10 characters")
      });
      
      const validation = schema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid request", 
          errors: validation.error.format() 
        });
      }
      
      // Store contact submission
      const contact = await storage.addContact(validation.data);
      
      res.status(201).json({ 
        message: "Contact form submitted successfully",
        contactId: contact.id
      });
    } catch (error) {
      console.error("Error in contact endpoint:", error);
      res.status(500).json({ 
        message: "An error occurred while submitting your contact form" 
      });
    }
  });

  // Get all contacts endpoint (admin only in a real app)
  app.get("/api/contact", async (_req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ 
        message: "An error occurred while fetching contacts" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
